﻿using System;
using System.Collections.Generic;

namespace Lab2
{
    public class Program
    {
        static void Main(string[] args)
        {

            //IsBalanced("{ int a = new int[ ] ( ( ) ) }");

            Evaluate("5 3 11 + -");

        }

        private static Dictionary<char, char> Balanced = new Dictionary<char, char>()
        {
            ['('] = ')',
            ['{'] = '}',
            ['<'] = '>',
            ['['] = ']',
        };

        public static bool IsBalanced(string s)
        {
            if (s.Length == 1) // is an empty string 'balanced'?
            {
                char character = s[0]; // toCharArray().First()
                return !(Balanced.ContainsKey(character) || Balanced.ContainsValue(character));
            }

            Stack<char> stack = new Stack<char>();

            foreach (char c in s)
            {
                // If opening symbol, then push onto stack
                if (Balanced.ContainsKey(c))
                {
                    stack.Push(c);
                }

                // If closing symbol, then see if it matches the top
                else if (c == '}' || c == '>' || c == ']' || c == ')') // Matchin
                {
                    if (stack.Count == 0) return false;
                    if (Matches(stack.Peek(), c))
                    {
                        stack.Pop();
                    }
                    else
                    {
                        return false;
                    }
                }

                // If any other character, then continue/ignore it.
                else
                {
                    continue;
                }
            }

            // If stack is empty, return true
            // else return false

            if (stack.Count == 0)
            {
                return true;
            }

            return false;
        }

        private static bool Matches(char open, char close)
        {
            // do the matching
            if (Balanced.TryGetValue(open, out char shouldClose)) // is it in the dictionary   
            {   
                return shouldClose == close;
                // return true
            }
            return false; // something else?
        }

        // Evaluate("5 3 11 + -")	// returns -9
        // 2.4 3.8 / 2.321 +

        public static HashSet<char> Operators = new HashSet<char>()
        {
            '+',
        };
        public static double? Evaluate(string s)
        {
            // parse into tokens (strings)

            string[] tokens = s.Split();

            Stack<double> stack = new Stack<double>();
            //if (Operators.TryGetValue)

            // foreach token
            foreach (string token in tokens)
            {
                // If token is an integer
                if (double.TryParse(token, out double num))
                {
                    stack.Push(num);
                }
                else // If token is an operator
                {
                    try
                    {
                        // Pop twice and save both values
                        double left = stack.Pop();
                        double right = stack.Pop();
                        switch (token) // Perform operation on 2 values (in the correct order)
                        // like EMDAS? I forgot what this means / does it matter?
                        {
                            case "+":
                                stack.Push(right + left); // Push the result on to stack
                                break;
                            case "-":
                                stack.Push(right - left);
                                break;
                            case "/":
                                stack.Push(right / left);
                                break;
                            case "*":
                                stack.Push(right * left);
                                break;
                            case "^":
                                stack.Push(Math.Pow(right, left));
                                break;
                        }
                    }
                    catch (InvalidOperationException)
                    {
                        return null; // (if you can't pop twice, then return null)
                    }
                }
            }           

            // i dunno
            if (stack.Count != 1)
            {
                return null;
            }

            return stack.Pop();
        }

    }
}
